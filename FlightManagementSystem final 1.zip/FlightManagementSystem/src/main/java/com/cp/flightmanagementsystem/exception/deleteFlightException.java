package com.cp.flightmanagementsystem.exception;

public class deleteFlightException extends Exception {
	
	   public deleteFlightException(String string) {
		   
		    super(string);
	   }

}
