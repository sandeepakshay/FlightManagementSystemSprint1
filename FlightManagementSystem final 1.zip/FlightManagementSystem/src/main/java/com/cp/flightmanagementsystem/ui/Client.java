package com.cp.flightmanagementsystem.ui;


import java.util.*;
import java.text.*;
import java.io.*;
import java.sql.Time;
import java.text.SimpleDateFormat;  
import java.util.Date;
import java.util.regex.Pattern;

import com.cp.flightmanagementsystem.dto.*;
import com.cp.flightmanagementsystem.dao.*;
import com.cp.flightmanagementsystem.exception.*;
import com.cp.flightmanagementsystem.services.*;
import com.cp.flightmanagementsystem.ui.*;
import com.cp.flightmanagementsystem.util.*;
import java.text.ParseException;


public class Client {

	public static void main(String[] args) throws ParseException, deleteFlightException {
		
		
		              ScheduledFlightService scheduledFlightService=new ScheduledFlightServiceImp();
		              AirportService airportService=new AirportServiceImp();
		              ScheduledFlightRepository ScheduledRepo=new ScheduledFlightRepository();
		              
		         
		              SimpleDateFormat sdf1 = new SimpleDateFormat("hh:mma"); 
		              SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy"); 
		              SimpleDateFormat sdf3=new SimpleDateFormat("dd/MM/yyyy");
		              SimpleDateFormat sdf4=new SimpleDateFormat("hh:mma");
		              Scanner scanner=new Scanner(System.in);
		              boolean flag=true;
		              

		           while(true) {
		            	  
		            	  
		            	        System.out.println("Enter 1 to Schedule Flights");
		            	        System.out.println("Enter 2 to view Scheduled Flight between two airports on specific date");
		            	        System.out.println("Enter 3 to view Scheduled Flight by Flight Name");
		            	        System.out.println("Enter 4 to view All Scheduled Flights");
		            	        System.out.println("Enter 5 to Modify Flights which are already Scheduled");
		            	        System.out.println("Enter 6 to Delete a Scheduled flight");
		            	        int choice=scanner.nextInt();
		            	        switch(choice) {
		            	        
		            	        
		            	        case 1:
		            	        	
		            	        	  System.out.print("Enter Flight Name: ");
		            	        	  
		            	        	  String flightname=scanner.next();
		            	        	  
		            	        	  System.out.print("Enter Number of seats capacity:");
		            	        	  int seats=scanner.nextInt();
		            	        	  System.out.print("Enter Source Airport Name:");
		            	        	  String sourceAirportName=scanner.next();
		            	        	  System.out.print("Enter Source Airport Location:");
		            	        	  String sourceAirportLoc=scanner.next();
		            	        	  System.out.print("Enter Source Airport Code:");
		            	        	  String sourceAirportCode=scanner.next();
		            	        	  System.out.print("Enter Destination Airport Name:");
		            	        	  String destinationAirportName=scanner.next();
		            	        	  System.out.print("Enter Destination Airport Location:");
		            	        	  String destinationAirportLoc=scanner.next();
		            	        	  System.out.print("Enter Destination Airport Code:");
		            	        	  String destinationAirportCode=scanner.next();
		            	        	 
		            	        	  System.out.print("Enter arrival Date :");
		            	        	  String arrivalDate=scanner.next();
		            	        	  System.out.print("Enter arrival Time:");
		            	        	  String arrivalTime=scanner.next();
		            	        	  Date ArrivalDate=sdf2.parse(arrivalDate);
		            	        	  Date ArrivalTime = sdf1.parse(arrivalTime);
		            	        	  
		            	        	  
		            	        	  System.out.print("Enter departure Date: ");
		            	        	  String departureDate=scanner.next();
		            	        	  System.out.print("Enter departure Time:");
		            	        	  String departureTime=scanner.next();
		            	        	  Date DepartureDate=sdf3.parse(departureDate);
		            	        	  Date DepartureTime = sdf4.parse(departureTime);
		            	        	  
		            	              
		            	        	  Airport airport1=new Airport(sourceAirportName,sourceAirportLoc,sourceAirportCode);
		            	        	  Airport airport2=new Airport(destinationAirportName,destinationAirportLoc,destinationAirportCode);
		            	        	  
		            	        	  
		            	        	  try {
		            	              if(scheduledFlightService.scheduleFlight(new ScheduledFlight(flightname,seats,new Schedule(airport1,airport2,ArrivalDate,DepartureDate,ArrivalTime,DepartureTime))))
		            	              {
		            	            	  System.out.println("Entered Successfully");
		            	              }
		            	        	  }
		            	        	  catch(ScheduledFlightServiceException e) {
		            	        		  
		            	        		  System.out.println(e);
		            	        	  }
		            	             
		            	        	  
		            	        	  
		            	        	  break;
		            	        	  
		            	       case 2:
		            	        	
		            	        	System.out.println("Location From:");
		            	        	String From=scanner.next();
		            	        	
		            	    	    Airport airport11=new Airport(null,From,null);
		            	    	    System.out.println("To:");
		            	    	    String To=scanner.next();
		            	        	Airport airport21=new Airport(null,To,null);
		            	        	System.out.println("Enter the Specific date:");
		            	        	String date=scanner.next();
		            	        	
		            	        	     
		            	        	List<ScheduledFlight> flightDemolist=scheduledFlightService.viewScheduledFlights(airport11, airport21, date);
		            	       
		            	           try {
		            	        	   if(flightDemolist!=null) {
		            	        	  for(ScheduledFlight obj:flightDemolist)
		            	        	  
		            	        		  {
		            	        		  
		            	        		     System.out.println("Data found");
		            	        		     System.out.println("****************************************************");
		            	        		     System.out.println(obj.getFlight());
		            	        		     System.out.println(sdf1.format(obj.getSchedule().getArrivalTime()));
		            	        		     System.out.println(sdf1.format(obj.getSchedule().getDepartureTime()));
		            	        		     System.out.println("****************************************************");
		            	        		     
		            	        		     
		            	        		     
		            	        	      }
		            	        	   }
		            	        	   else
		            	        		   throw new NullPointerException("No data found");
		            	        	     
		            	           }
		            	           catch(NullPointerException e) {
		            	        	    System.out.println(e.getMessage());
		            	           }
		            	       
                                   break;
                                   
		                        case 3: 	 
		            	   
		            	    	 System.out.print("Enter the flight name to get Scheduled details of the particular:");
		            	    	 
		            	    	 String flightname1=scanner.next();
		            	    	 
		            	    	 List<ScheduledFlight> outputList=scheduledFlightService.viewScheduledFlights2(flightname1);
		            	    	 
		            	    	 try {
			            	    	 if(outputList!=null) {
			            	    	 
			            	    	  for(ScheduledFlight element:outputList) {
			            	    		  
			            	    		     
			            	    		     System.out.println("********************************************************");
			            	    		     System.out.println("Flight Name: "+element.getFlight());
			            	    		     System.out.println("From: "+element.getSchedule().getSourceAirport().getAirportLocation());
		            	        		     System.out.println("To: "+element.getSchedule().getDestinationAirport().getAirportLocation());
		            	        		      System.out.println("Arrival Time: "+sdf1.format(element.getSchedule().getArrivalTime()));
		            	        		      System.out.println("Arrival Date: "+sdf2.format(element.getSchedule().getArrivalDate()));
		            	        		     System.out.println("Departure Time: "+sdf1.format(element.getSchedule().getDepartureTime()));
		            	        		     System.out.println("Departure Date: "+sdf2.format(element.getSchedule().getDepartureDate()));
		            	        		     System.out.println("********************************************************");
			            	    		     }
			            	    		     
			            	    	  }
			            	    	 else
			            	    	 {
			            	    		 throw new NullPointerException("Its a null,No List Found");
			            	    	 }
			            	    	 }
			            	    	 catch(NullPointerException e) {
			            	    		 
			            	    		   System.out.println(e.getMessage());
			            	    	 }
			            	    	  
		            	    	 
		            	    	    break;
		            	        	  
		            	        	  
		            	    case 4:
		            	    	 
		            	    	    
		            	    	 List<ScheduledFlight> output= scheduledFlightService.viewScheduleFlight();
		            	    	 
		            	    	 try {
		            	    	 if(output!=null) {
		            	    	 
		            	    	  for(ScheduledFlight element:output) {
		            	    		  
		            	    		     System.out.println("********************************************************");
		            	    		     System.out.println("Flight Name: "+element.getFlight());
		            	    		     System.out.println("From: "+element.getSchedule().getSourceAirport().getAirportLocation());
	            	        		     System.out.println("To: "+element.getSchedule().getDestinationAirport().getAirportLocation());
	            	        		      System.out.println("Arrival Time: "+sdf1.format(element.getSchedule().getArrivalTime()));
	            	        		      System.out.println("Arrival Date: "+sdf2.format(element.getSchedule().getArrivalDate()));
	            	        		     System.out.println("Departure Time: "+sdf1.format(element.getSchedule().getDepartureTime()));
	            	        		     System.out.println("Departure Date: "+sdf2.format(element.getSchedule().getDepartureDate()));
	            	        		     System.out.println("********************************************************");
		            	    		     }
		            	    		     
		            	    	  }
		            	    	 else
		            	    	 {
		            	    		 throw new EmptyListException("No List Found");
		            	    	 }
		            	    	 }
		            	    	 catch(EmptyListException e) {
		            	    		 
		            	    		   System.out.println(e.getMessage());
		            	    	 }
		            	    	  
		            	    	  break;
		            	    	   
		            	    case 5:
		            	    	 
		            	    	  
		            	    	 System.out.println("Enter the flight name:");
		         				 String flightname2=scanner.next();
		         				 
		         				if(flightname2==null)
		         				{
		         				   System.out.println("You Entered nothing");
		         				}
		        
		         				else
		         				{       ScheduledFlight updateFlight=scheduledFlightService.modifyScheduledFlight(flightname2);
		         						System.out.println("Enter 1 to change Flight Name");
		         						System.out.println("Enter 2 to change Source airport location");
		         						System.out.println("Enter 3 to change destination airport location");
		         						System.out.println("Enter 4 to change Arrival Date");
		         						System.out.println("Enter 5 to change Departure Date");
		         						System.out.println("Enter 6 to change Arrival Time");
		         						System.out.println("Enter 7 to change Departure Time");
		         						System.out.println("Please enter your choice");
		         						int choice1=scanner.nextInt();
		         						switch(choice1)
		         						{
		         						case 1:
		         							System.out.println("Enter the name you want to change:");
		         							String name=scanner.next();
		         							updateFlight.setFlight(name);
		         							System.out.println("********Name changed sucessfully***********");
		         							break;
		         						case 2:
		         							
		         							  System.out.println("Enter the  source airport location:");
		         							  String sourceAirport=scanner.next();
		         							  
		         						        
		         							   updateFlight.getSchedule().getSourceAirport().setAirportLocation(sourceAirport);
		         							   System.out.println("*********source airport location changed Sucessfully**********");
		         							   
		         							break;
		         						case 3:
		         							  System.out.println("Enter the  destination airport location:");
		         							  String destAirport=scanner.next();
		         							  updateFlight.getSchedule().getDestinationAirport().setAirportLocation(destAirport);
		         							   System.out.println("**********source airport location changed Sucessfully*************");
		         							break;
		         						case 4:
		         							System.out.println("Enter the Arrival Date you want to change:");
		         							String Arrivaldate =scanner.next();
		         							Date d1=sdf2.parse(Arrivaldate);
		         							updateFlight.getSchedule().setArrivalDate(d1);
		         							System.out.println("********************Arrival Date changed**********************");
		         						    
		         							break;
		         						case 5:
		         							System.out.println("Enter the Destination Date you want to change:");
		         							String DestDate=scanner.next();
		         							Date d2=sdf2.parse(DestDate);
		         							updateFlight.getSchedule().setDepartureDate(d2);
		         							System.out.println("******************* Destination Date changed******************");
		         							break;
		         						case 6:
		         							System.out.println("Enter Arrival Time you want to change :");
		         							String Arrivaltime=scanner.next();
		         							Date d3=sdf1.parse(Arrivaltime);
		         							updateFlight.getSchedule().setArrivalTime(d3);
		         							System.out.println("*******************Arrival Time changed***********************");
		         							break;
		         						case 7:
		         							System.out.println("Enter Departure Time you want to change:");
		         							String DestTime=scanner.next();
		         							Date d4=sdf1.parse(DestTime);
		         							updateFlight.getSchedule().setDepartureTime(d4);
		         							System.out.println("******************Departure Time changed**********************");
		         							
		         						}
		         				}
		         					
		         					 break;
		            	        	  
		         				
		         			 case 6:
		         						  
		         						   System.out.println("Enter the flight name which you want to delete:");
		         						   String FlightName=scanner.next();
		      
				            	        		  
				            	           System.out.println(scheduledFlightService.deleteScheduledFlight(FlightName));
				            	        		
		         						 
		              
		         						   
		         						   break;
		              
		         			       
		              }
	            	        }
		            	  
	  }
		              
}		          




