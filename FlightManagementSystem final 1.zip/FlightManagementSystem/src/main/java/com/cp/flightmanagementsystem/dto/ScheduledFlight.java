package com.cp.flightmanagementsystem.dto;

public class ScheduledFlight {

	        
	          String flight;
	          int availableSeats;
	          Schedule schedule;
	          
	           public ScheduledFlight(String flight,int availableSeats,Schedule schedule2){
	        	   
	        	      this.flight=flight;
	        	      this.availableSeats=availableSeats;
	        	      this.schedule=schedule2;
	        	   
	           }
	           public void setFlight(String flight) {
				this.flight = flight;
			}
			public void setAvailableSeats(int availableSeats) {
				this.availableSeats = availableSeats;
			}
			public void setSchedule(Schedule schedule) {
				this.schedule = schedule;
			}
			public String getFlight() {
	        	   
	        	   return flight;
	           }
	           public int getAvailableSeats() {
	        	   
	        	   return availableSeats;
	           }
	           public Schedule getSchedule() {
	        	   
	        	     return schedule;
	           }
	
	       
}
