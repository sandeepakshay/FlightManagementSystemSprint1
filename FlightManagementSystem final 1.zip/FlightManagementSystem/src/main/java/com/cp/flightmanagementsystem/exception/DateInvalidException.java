package com.cp.flightmanagementsystem.exception;

public class DateInvalidException extends Exception {
	
	    public DateInvalidException(String string) {
	    	
	    	super(string);
	    }

}
