package com.cp.flightmanagementsystem.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cp.flightmanagementsystem.dao.ScheduledFlightDaoImp;
import com.cp.flightmanagementsystem.dto.Airport;
import com.cp.flightmanagementsystem.dto.Schedule;
import com.cp.flightmanagementsystem.dto.ScheduledFlight;
import com.cp.flightmanagementsystem.exception.ScheduledFlightServiceException;
import com.cp.flightmanagementsystem.exception.deleteFlightException;
import com.cp.flightmanagementsystem.services.ScheduledFlightServiceImp;
import com.cp.flightmanagementsystem.ui.Client;

public class ScheduledFlightServiceTest {
	
	
	ScheduledFlightServiceImp scheduledFlightservice=new ScheduledFlightServiceImp();
    SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdf2=new SimpleDateFormat("hh:mma");
     
	
	  @Test
	  
	  public void scheduleFlightServiceTest() throws ParseException,ScheduledFlightServiceException {
	  
	  ScheduledFlight Result= new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new  Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm")));
	  
	  
	  Assertions.assertTrue(scheduledFlightservice.scheduleFlight(Result)); 
	  
	  }
	  
	  @Test 
	  
	  public void viewScheduledFlightsServiceTest() throws ParseException,ScheduledFlightServiceException {
	  
	  
	scheduledFlightservice.scheduleFlight(new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm"))));
		   
		  
	  
	  List<ScheduledFlight> list1=scheduledFlightservice.viewScheduledFlights2("6E5566");
	  
	  assertEquals("6E5566",list1.get(0).getFlight()); 
	  
	  }
	  
	  @Test 
	  
	  public void viewScheduleFlightServiceTest() throws ParseException, ScheduledFlightServiceException{
	  
	  
	  
	  scheduledFlightservice.scheduleFlight(new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm"))));
		   
		  
	  
	  List<ScheduledFlight> list=scheduledFlightservice.viewScheduleFlight();
	  
	  Assertions.assertEquals("6E5566", list.get(0).getFlight()); }
	  
 @Test public void modifyScheduledFlightServiceTest() throws ParseException, ScheduledFlightServiceException{
	  
	  
	 scheduledFlightservice.scheduleFlight(new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm"))));
	   
	  
	  
	  ScheduledFlight obj=scheduledFlightservice.modifyScheduledFlight("6E45");
	  
	  assertEquals(null,obj);
	  
	  }
	 
   
   @Test
   public void deleteScheduledFlightServiceTest() throws ParseException, deleteFlightException, ScheduledFlightServiceException{
	   
	   
	   scheduledFlightservice.scheduleFlight(new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm"))));
	   
	   String output=scheduledFlightservice.deleteScheduledFlight("6E5566");
	   
	   
	   assertEquals("deleted",output);
	   
   }
   
  
  
/*	
	  @Test public void viewScheduledFlightsDateServiceTest() throws ParseException
	  {
	  
	  
	  ScheduledFlight Result=new ScheduledFlight("6E5566",300,new Schedule(new
	  Airport("vizag_airport","airport","VTZ"),new
	  Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse(
	  "21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm")));
	  
	  List<ScheduledFlight> list=scheduledFlightservice.viewScheduledFlights(new
	  Airport("vizag_airport","airport","VTZ"),new
	  Airport("delhi_airport","delhi","DEL") ,"21/02/2020" );
	  
	  assertEquals(Result,list.get(0));
	  
	  }*/
	 
}
