
  package com.cp.flightmanagementsystem.daotest;
  
  import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.text.ParseException; import java.text.SimpleDateFormat; import
  java.util.List;
  
  import org.junit.jupiter.api.Assertions; import
  org.junit.jupiter.api.Assertions.*; import org.junit.jupiter.api.Test; import
  org.junit.jupiter.api.*;
  
  
  import com.cp.flightmanagementsystem.dao.ScheduledFlightDaoImp; import
  com.cp.flightmanagementsystem.dto.*;
import com.cp.flightmanagementsystem.util.ScheduledFlightRepository;
  
  
  public class ScheduledFlightServiceDaoTest {
  
  
  
  ScheduledFlightDaoImp scheduledFlightDao=new ScheduledFlightDaoImp();
  ScheduledFlightRepository Repo=new ScheduledFlightRepository();
  SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy"); SimpleDateFormat
  sdf2=new SimpleDateFormat("hh:mma");
  
  @Test
  public void scheduleFlightDaoTest() throws ParseException {
  
	  ScheduledFlight Result=new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm")));
	  
	  
  
  
      Assertions.assertTrue(scheduledFlightDao.scheduleFlightDao(Result)); }
  
  @Test
  public void viewScheduledFlightsDaoTest() throws ParseException {
  
  
	  scheduledFlightDao.scheduleFlightDao(new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm"))));
	  
        List<ScheduledFlight> list1=scheduledFlightDao.viewScheduledFlightsDao2("6E5566");
       
  
          assertEquals("6E5566",list1.get(0).getFlight());
       }
  
  
  @Test public void viewScheduleFlightDaoTest() throws ParseException{
  
  
  
	  ScheduledFlight Result=new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm")));
	  
	  
  
      List<ScheduledFlight> list=scheduledFlightDao.viewScheduleFlightDao();
  
      Assertions.assertEquals(Result.getFlight(), list.get(0).getFlight()); }
  
  
  
  @Test public void modifyScheduledFlightDaoTest() throws ParseException{
  
  
	  ScheduledFlight Result=new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm")));
	  
	  
  
      ScheduledFlight obj=scheduledFlightDao.modifyScheduledFlightDao("6E5");
  
      assertEquals(null,obj);
  
  }
  
  @Test public void deleteScheduledFlightDaoTest() throws ParseException{
  
  
	  scheduledFlightDao.scheduleFlightDao(new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm"))));
      
	  String actual=scheduledFlightDao.deleteScheduledFlightDao("6E5566");
  
      Assertions.assertEquals("deleted",actual);
  
  
  }
  
  
 /* 
  @Test public void viewScheduledFlightsDateDaoTest() throws ParseException {
  
  
	  ScheduledFlight Result=new ScheduledFlight("6E5566",300,new Schedule(new Airport("vizag_airport","airport","VTZ"),new Airport("delhi_airport","delhi","DEL"),sdf1.parse("21/02/2020"),sdf1.parse("21/02/2020"),sdf2.parse("02:30pm"),sdf2.parse("04:30pm")));
	  
	  
  
       List<ScheduledFlight> list=scheduledFlightDao.viewScheduledFlightsDao(new
       Airport("vizag_airport","airport","VTZ"),new
       Airport("delhi_airport","delhi","DEL") ,"21/02/2020" );
  
  assertEquals(Result.getFlight(),list.get(0).getFlight());
  
  }
  */
  }
 