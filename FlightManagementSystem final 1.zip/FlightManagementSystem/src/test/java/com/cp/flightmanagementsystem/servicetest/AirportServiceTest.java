package com.cp.flightmanagementsystem.servicetest;

import java.util.List;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cp.flightmanagementsystem.dto.Airport;
import com.cp.flightmanagementsystem.services.AirportServiceImp;

public class AirportServiceTest {
	
	  
	
	  AirportServiceImp airportservice=new AirportServiceImp();
	  
	  @Test public void viewAirportDaoTest() {
	  
	  
	  List<Airport> airportList=airportservice.viewAirport(); Airport air=new
	  Airport("vizag_airport","vizag","VTZ");
	  
	  Assertions.assertEquals("vizag_airport",airportList.get(0).getAirportName());
	  
	  
	  }
	  
	  @Test public void viewAirportDaoTest2() {
	  
	  
	  
	  Airport air=new Airport("vizag_airport","vizag","VTZ");
	  
	  List<Airport> airportList=airportservice.viewAirport("VTZ");
	  
	  Assertions.assertEquals(air.getAirportLocation(),airportList.get(0).
	  getAirportLocation()); }
	 


}
