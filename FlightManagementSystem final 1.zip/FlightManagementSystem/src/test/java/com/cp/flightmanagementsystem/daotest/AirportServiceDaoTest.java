package com.cp.flightmanagementsystem.daotest;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.*;

import com.cp.flightmanagementsystem.dao.AirportDaoImp;
import com.cp.flightmanagementsystem.dto.Airport;
import com.cp.flightmanagementsystem.dto.Schedule;
import com.cp.flightmanagementsystem.dto.ScheduledFlight;
import com.cp.flightmanagementsystem.services.AirportServiceImp;
import com.cp.flightmanagementsystem.util.AirportRepository;

public class AirportServiceDaoTest {
	
	         
	
	  Object expectedArray[]=new Object[10]; AirportRepository airportRepo=new
	  AirportRepository(); AirportDaoImp airportservicedao=new
	  AirportDaoImp();
	  
	  
	  
	  
	  
	  @Test public void viewAirportDaoTest() {
	  
	  
	  List<Airport> airportList=airportservicedao.viewAirportDao(); Airport air=new
	  Airport("vizag_airport","vizag","VTZ");
	  
	  Assertions.assertEquals("vizag_airport",airportList.get(0).getAirportName());
	  
	  
	  }
	  
	  @Test public void viewAirportDaoTest2() {
	  
	  
	  
	  Airport air=new Airport("vizag_airport","vizag","VTZ");
	  
	  List<Airport> airportList=airportservicedao.viewAirportDao("VTZ");
	  
	  Assertions.assertEquals(air.getAirportLocation(),airportList.get(0).
	  getAirportLocation()); }
	  
	  
	  
	 }
